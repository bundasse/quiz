<template>
  <div class="w-full flex justify-center items-center h-full">
    <div class="mx-auto w-10/12 lg:w-6/12 flex flex-wrap items-center">
      <div class="w-full bg-white rounded-lg p-5 gap-x-5 flex flex-wrap justify-center">
        <input @input="chk()" v-model="userName" type="text" class="border pl-4 py-2 rounded-md shadow-md outline-none basis-full sm:basis-5/12">
        <button @click="NameChk()" class="text-sm sm:text-base btn-primary bg-blue-500 hover:bg-blue-700 focus:ring-blue-400 sm:py-0 basis-full sm:basis-3/12 mt-5 sm:mt-0">시작하기 </button>
        <div class="mt-4 text-xs sm:text-sm font-bold" v-if="userName.length > 2">{{ userName }} 님 반갑습니다. 총 {{dataList.QuizList.length}}개의 문제가 준비되어있습니다.</div>
        <!-- 조건문을 활용해 유저네임의 글자 수가 3자리 이상이라면 화면에 출력 -->
      </div>
      <div class="fixed bg-white left-1/2 top-[48%] -translate-x-1/2 -translate-y-1/2 z-50 border rounded-lg duration-700 transition-all w-3/4 sm:w-2/4 lg:w-1/6 error opacity-0 invisible">
        <h3 class="bg-gray-100 p-2 pl-4">경고창</h3>
        <p class="p-4 py-6">{{ errorMsg }}</p>
      </div>
    </div>
  </div>
  
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { RouteLocationRaw } from 'vue-router';
import QuizList from "../assets/QuizList.json";

export default defineComponent({
  name: 'HomeView',
  data() {
    return {
      errorMsg: "이름을 입력해주세요",
      userName: "",
      dataList : QuizList
    }
  },
  methods:{
    chk(){
      const regex = /^[가-힣]*$/;
      if(!regex.test(this.userName)){
        this.userName = this.userName.replace(/[^가-힣]*/, '');
      }
    },
    NameChk() {
      if(!this.userName){
        const errorEl = document.querySelector(".error");
        errorEl?.classList.remove('invisible', 'opacity-0', 'top-[48%]');
        errorEl?.classList.add('top-1/2', 'opacity-1')
        setTimeout(() => {
          errorEl?.classList.add('invisible', 'opacity-0', 'top-[48%]');
          errorEl?.classList.remove('top-1/2', 'opacity-1')
        }, 2500);
      }else{
        const route : RouteLocationRaw = {name: "QuizView", replace : true}
        this.$router.push(route)
      }
    }
  },  
  components: {
    
  },
});
</script>
